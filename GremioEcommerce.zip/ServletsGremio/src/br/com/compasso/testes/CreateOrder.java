package br.com.compasso.testes;

import static org.junit.Assert.*;

import org.junit.Test;

import br.com.compasso.modelo.Pedido;
import br.com.compasso.modelo.PedidoDAO;
import br.com.compasso.modelo.Produto;
import br.com.compasso.modelo.Usuario;
import br.com.compasso.modelo.UsuarioDAO;

public class CreateOrder {

	@Test
	public void testCreateOrder() {
		Usuario user = new Usuario();
		UsuarioDAO userDao = new UsuarioDAO();
		user = userDao.getLista().get(0);

		int qtd = 2;
		Pedido pedido = new Pedido();
		pedido.setUsuario(user);
		Produto product = new Produto();
		pedido.setProduto(product.getAll().get(0));
		pedido.setQuantidade(qtd);		
		pedido.setValue(product.getAll().get(0).getValor());
		int total = product.getAll().get(0).getValor() * qtd;
		
		PedidoDAO order = new PedidoDAO();
		order.insere(pedido);
		
		assertEquals(pedido.getProduto().getNome(), "Camisa Tricolor Masc. I 2016");
		assertTrue(pedido.getQuantidade() == qtd);
		assertTrue(pedido.getValor() == total);
	}

}