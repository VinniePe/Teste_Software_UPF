package br.com.compasso.testes;

import static org.junit.Assert.*;

import org.junit.Test;

import br.com.compasso.modelo.Usuario;
import br.com.compasso.modelo.UsuarioDAO;

public class CreateUser {

	@Test
	public void testCreateUser() {
		Usuario user = new Usuario();
		user.setEmail("teste@teste.com");
		user.setSenha("123456");
		user.setCpf("025.708.040-37");
		user.setNome("Jo�o");
		user.setSobrenome("Santos");
		user.setSexo("Masculino");
		user.setDataNascimento("04/05/2000");
		user.setTelefone("(54)3322-1100");
		
		boolean userAdd = createUser(user);
		assertTrue(userAdd);
		
		
		Usuario user2 = new Usuario();
		user2.setEmail("teste@teste.com");
		user2.setSenha("123456");
		user2.setCpf("023.807.040-32");
		user2.setNome("Paulo");
		user2.setSobrenome("Silva");
		user2.setSexo("Masculino");
		user2.setDataNascimento("01/02/1999");
		user2.setTelefone("(54)9988-7766");
		
		userAdd = createUser(user2);
		assertFalse(userAdd);
		
		String validaEmail = "teste@teste.com";
		boolean userAllRexists = validateLogin(validaEmail);
		assertTrue(userAllRexists);
		
		validaEmail = "teste2@teste2.com";
		userAllRexists = validateLogin(validaEmail);
		assertFalse(userAllRexists);	
	}
	public boolean createUser(Usuario user){
		UsuarioDAO userDao = new UsuarioDAO();
		try {
			if(!validateLogin(user.getEmail())){
				if(userDao.validateUser(user)){
					userDao.insere(user);
					System.out.println("Usu�rio '" + user.getNome() + " " + user.getSobrenome() + "' adicionado.");
					return true;
				}
			}else{
				System.out.println("Erro ao tentar adicionar o usu�rio '" + user.getNome() + " " + user.getSobrenome() + "'.");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}
	
	public boolean validateLogin(String validaEmail){
		UsuarioDAO userDao = new UsuarioDAO();
		if(userDao.loginAllReadyExists(validaEmail)){
			return true;
		}else{
			return false;
		}
	}
}
